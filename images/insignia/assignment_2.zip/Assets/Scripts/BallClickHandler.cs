using UnityEngine;
using UnityEngine.SceneManagement;

public class BallClickHandler : MonoBehaviour
{
    public Camera activeCamera;  // 当前使用的摄像机

    void Update()
    {
        // 检测鼠标左键点击（0 表示左键）
        if (Input.GetMouseButtonDown(0))
        {
            // 创建射线从当前激活的摄像机指向鼠标位置
            Ray ray = activeCamera.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;

            // 发射射线，并检测是否点击到了某个物体
            if (Physics.Raycast(ray, out hit))
            {
                // 如果射线检测到的物体是球体自身
                if (hit.transform == transform)
                {
                    // 如果点击了球体，切换回主菜单场景
                    SceneManager.LoadScene("MainMenu");
                }
            }
        }
    }

    // 设置当前激活的摄像机
    public void SetActiveCamera(Camera camera)
    {
        activeCamera = camera;
    }
}

// using UnityEngine;
// using UnityEngine.SceneManagement;

// public class BallClickHandler : MonoBehaviour
// {
//     // 更新函数，用于每帧检测鼠标点击
//     void Update()
//     {
//         // 检测鼠标左键点击（0 表示左键）
//         if (Input.GetMouseButtonDown(0))
//         {
//             // 创建射线从摄像机指向鼠标位置
//             Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
//             RaycastHit hit;

//             // 发射射线，并检测是否点击到了某个物体
//             if (Physics.Raycast(ray, out hit))
//             {
//                 // 如果射线检测到的物体是球体自身
//                 if (hit.transform == transform)
//                 {
//                     // 如果点击了球体，切换回主菜单场景
//                     SceneManager.LoadScene("MainMenu");
//                 }
//             }
//         }
//     }
// }

