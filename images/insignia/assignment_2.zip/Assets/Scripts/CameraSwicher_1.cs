using UnityEngine;

public class CameraSwitcher : MonoBehaviour
{
    public Camera camera1;  // 主摄像机
    public Camera camera2;  // 次摄像机
    public BallClickHandler ballClickHandler;  // 引用 BallClickHandler

    private bool isCamera1Active = true;

    void Start()
    {
        // 初始状态下，激活 Camera1，禁用 Camera2
        camera1.enabled = true;
        camera2.enabled = false;
        
        // 设置 BallClickHandler 的当前摄像机为 Camera1
        ballClickHandler.SetActiveCamera(camera1);
    }

    void Update()
    {
        // 检测空格键按下
        if (Input.GetKeyDown(KeyCode.Space))
        {
            // 切换摄像机
            isCamera1Active = !isCamera1Active;
            camera1.enabled = isCamera1Active;
            camera2.enabled = !isCamera1Active;

            // 更新 BallClickHandler 使用的摄像机
            if (isCamera1Active)
            {
                ballClickHandler.SetActiveCamera(camera1);
            }
            else
            {
                ballClickHandler.SetActiveCamera(camera2);
            }
        }
    }
}


// using UnityEngine;

// public class CameraSwitcher : MonoBehaviour
// {
//     public Camera camera1;  // 主摄像机
//     public Camera camera2;  // 次摄像机

//     private bool isCamera1Active = true;

//     void Start()
//     {
//         // 初始状态下，激活 Camera1，禁用 Camera2
//         camera1.enabled = true;
//         camera2.enabled = false;
//     }

//     void Update()
//     {
//         // 检测空格键按下
//         if (Input.GetKeyDown(KeyCode.Space))
//         {
//             // 切换摄像机
//             isCamera1Active = !isCamera1Active;
//             camera1.enabled = isCamera1Active;
//             camera2.enabled = !isCamera1Active;
//         }
//     }
// }
