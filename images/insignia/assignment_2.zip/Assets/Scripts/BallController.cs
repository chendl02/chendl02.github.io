using UnityEngine;
using UnityEngine.SceneManagement;

public class BallController : MonoBehaviour
{
    // public Camera mainCamera; // 主摄像机

    public Camera mainCamera;  // 当前使用的摄像机
    public Camera camera1;     // 摄像机1
    public Camera camera2;     // 摄像机2

    public float moveSpeed = 5f;  // 球体移动的速度
    public float roomBoundary = 5f;  // 房间边界，用于限制球体在房间内移动
    public float squashFactor = 0.5f; // 压缩比例
    public float wallThickness = 0.5f; // 墙壁的厚度
    public float floorHeight = 0f; // 地板的高度
    public float ceilingHeight = 5f; // 天花板的高度

    private Vector3 originalScale;

    void Start()
    {
        // 设置当前使用的摄像机为 Camera1
        mainCamera = camera1;
        camera1.enabled = true;
        camera2.enabled = false;
        // 记录球体的原始缩放比例
        originalScale = transform.localScale;
    }

    void Update()
    {
        // 切换摄像机，当按下空格键时
        if (Input.GetKeyDown(KeyCode.Space))
        {
            ToggleCamera();
        }
        // 获取鼠标在屏幕上的位置
        Vector3 mousePosition = Input.mousePosition;

        // 将鼠标位置转换为摄像机视角中的平面（屏幕到世界坐标）
        Ray ray = mainCamera.ScreenPointToRay(mousePosition);
        Plane cameraPlane = new Plane(mainCamera.transform.forward, Vector3.zero);  // 创建与相机方向垂直的平面
        float distance;

        if (cameraPlane.Raycast(ray, out distance)&&camera1.enabled)
        {
            // 获取射线与相机垂直平面的交点
            Vector3 worldMousePosition = ray.GetPoint(distance);

            // 限制球体的移动，防止它超出房间边界
            Vector3 targetPosition = new Vector3(
                //Mathf.Clamp(worldMousePosition.x, -roomBoundary, roomBoundary),  // 限制 X 轴
                transform.position.x,
                Mathf.Clamp(worldMousePosition.y, floorHeight+0.2f, ceilingHeight-0.2f),  // 限制 Y 轴（基于地板和天花板）
                Mathf.Clamp(worldMousePosition.z, -roomBoundary + wallThickness+0.2f, roomBoundary - wallThickness-0.2f)   // 限制 Z 轴
            );

            // 平滑移动球体到目标位置
            transform.position = Vector3.Lerp(transform.position, targetPosition, Time.deltaTime * moveSpeed);

            // 应用挤压效果
            ApplySquashEffect(targetPosition);
        }
        if (cameraPlane.Raycast(ray, out distance)&&camera2.enabled)
        {
            // 获取射线与相机垂直平面的交点
            Vector3 worldMousePosition = ray.GetPoint(distance);

            // 限制球体的移动，防止它超出房间边界
            Vector3 targetPosition = new Vector3(
                //Mathf.Clamp(worldMousePosition.x, -roomBoundary, roomBoundary),  // 限制 X 轴
                Mathf.Clamp(worldMousePosition.x, -roomBoundary + wallThickness+0.2f, roomBoundary - wallThickness-0.2f),  // 限制 X 轴vcxz
                Mathf.Clamp(worldMousePosition.y, floorHeight+0.2f, ceilingHeight-0.2f),  // 限制 Y 轴（基于地板和天花板）
                
                transform.position.z
            );

            // 平滑移动球体到目标位置
            transform.position = Vector3.Lerp(transform.position, targetPosition, Time.deltaTime * moveSpeed);

            // 应用挤压效果
            ApplySquashEffect(targetPosition);
        }
        

        // 检测鼠标左键点击，点击后返回主菜单
        if (Input.GetMouseButtonDown(0))
        {
            SceneManager.LoadScene("MainMenu");
        }
    }

    void ApplySquashEffect(Vector3 position)
    {
        Vector3 newScale = originalScale;

        // 计算球体与房间边界（地板、天花板、墙壁）的距离，并考虑墙壁厚度
        float distanceToFloor = position.y - floorHeight;  // 距离地板的距离
        float distanceToCeiling = ceilingHeight - position.y;  // 距离天花板的距离
        float distanceToWallX = roomBoundary - wallThickness - Mathf.Abs(position.x);  // 距离X轴墙壁的距离
        float distanceToWallZ = roomBoundary - wallThickness - Mathf.Abs(position.z);  // 距离Z轴墙壁的距离

        // 当靠近地板或天花板时，垂直压缩
        if (distanceToFloor < 0.5f || distanceToCeiling < 0.5f)
        {
            float squashAmount = Mathf.Lerp(squashFactor, 1f, Mathf.Min(distanceToFloor, distanceToCeiling));
            newScale.y = squashAmount;
            newScale.x = Mathf.Lerp(originalScale.x, originalScale.x + (1f - squashAmount), 0.5f); // 横向扩展
            newScale.z = Mathf.Lerp(originalScale.z, originalScale.z + (1f - squashAmount), 0.5f);
        }

        // 当靠近墙壁时，水平压缩
        
        if (distanceToWallX < 0.5f)
        {
            float squashAmount = Mathf.Lerp(squashFactor, 1f, distanceToWallX);
            newScale.x = squashAmount;
            newScale.z = Mathf.Lerp(originalScale.z, originalScale.z + (1f - squashAmount), 0.5f);
            newScale.y = Mathf.Lerp(originalScale.y, originalScale.y + (1f - squashAmount), 0.5f);
        }

        if (distanceToWallZ < 0.5f)
        {
            float squashAmount = Mathf.Lerp(squashFactor, 1f, distanceToWallZ);
            newScale.z = squashAmount;
            newScale.x = Mathf.Lerp(originalScale.x, originalScale.x + (1f - squashAmount), 0.5f);
            newScale.y = Mathf.Lerp(originalScale.y, originalScale.y + (1f - squashAmount), 0.5f);
        }

        // 平滑应用压缩缩放效果
        transform.localScale = Vector3.Lerp(transform.localScale, newScale, Time.deltaTime * moveSpeed);
    }
    // 切换当前摄像机
    void ToggleCamera()
    {
        if (mainCamera == camera1)
        {
            mainCamera = camera2;
            camera1.enabled = false;
            camera2.enabled = true;
        }
        else
        {
            mainCamera = camera1;
            camera2.enabled = false;
            camera1.enabled = true;
        }
    }
}
